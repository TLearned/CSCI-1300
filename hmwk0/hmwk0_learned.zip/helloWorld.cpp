#include <iostream>
using namespace std;

int main()
{
	std::cout << "Hello world! Hello CSCi 1300" << std::endl;
}