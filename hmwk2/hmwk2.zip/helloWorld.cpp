// CS1300 Fall 2019
// Author: Tyler Learned
// Recitation: 1300-301 - No Favorite TA
// Homework 2 - Problem 1

#include <iostream>
using namespace std;

int main()
{
    cout << "Hello, World!" << endl; // Output Hello, World!
}