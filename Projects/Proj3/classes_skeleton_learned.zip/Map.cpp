#include "map.h"

Map :: Map()
{
    ground_tile = a;
    water_tile = a;
    gym_tile = a;
    center_tile = a;
}

Map :: Map(string aGT, string aWT, string aGyT, string aCT)
{
    ground_tile = aGT;
    water_tile = aWT;
    gym_tile = aGyT;
    center_tile = aCT;
}

void Map :: readFile()
{
    //get line through file using split to see what characters are there
}

char Map :: getGround()
{
    return "*";
}

void Map :: setGround(char G)
{
    //store position of ground tile
}

char Map :: getWater()
{
    return "~";
}

void Map :: setWater(char W)
{
    //store position of water tile
}

char Map :: getGym()
{
    return "G";
}

void Map :: setGym(char Gy)
{
    //store position of gym tile
}

char Map :: getCenter()
{
    return "C";
}

void Map :: setCenter(char C)
{
    //store location of center tile
}