#include "user.h"

Usr :: User()
{
    username = "";
    num_pokemon = 0;
    points = 0;
    num_pokeballs = 0;
}

User :: User(string aUsername, int aNum_pokemon, int aPoints, int aNum_pokeballs)
{
    username = aUsername;
    numPokemon = aNum_pokemon;
    points = aPoints;
    num_pokeballs = aNum_pokeballs;
}

User :: string getUsername()
{
    return username;
}

void User :: setUsername(string u)
{
    username = u;
}

int User :: getNum_pokemon()
{
    return num_pokemon;
}

void User :: setNum_pokemon(int pM)
{
    num_pookemon = pM;
}

int User :: getPoints()
{
    return points;
}

void User :: setPoints(int p)
{
    points = p;
}

int User :: getNum_pokeballs()
{
    return num_pokeballs;
}

void User :: setNum_pokeballs(int pB)
{
    num_pokeballs = pB;
}

string User :: move()
{
    int choice = 0;
    while(choice != 4)
    {
        if( choice == 1)
        {
            //Travel
            {
                
            }
        }
        
        else if(choice == 2)
        {
            /*rest
            hp + 1
            num_pokeballs - 1
            location = location*/
        }
        
        else if(choice == 3)
        {
            /*try luck
            location = location
            if wild encounter 50% chance catch and num_pokeballs = num_pokeballs*/
        }
        
        else if(choice == 4)
        {
            Quit;
        }
        
        else
        {
            cout << "Enter a valid choice" << endl;
        }
    }
}