#include "center.h"

Center :: Center()
{
    pokedex[] = {};
    party[] = {};
}

Center :: Center(array, array)
{
    pokedex[] = aPokedex[];
    party[] = aParty[];
}

string get_pokedex()
{
    //return the pokedex array
}

void Center :: set_pokedex(array)
{
    //sets the pokemon in the pokedex when changed
}

string Center :: get_party()
{
    //return the party array
}

void Center :: set_party(array)
{
    //sets the party when changed
}