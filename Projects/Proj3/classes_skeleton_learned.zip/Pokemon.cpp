#include "pokemon.h"

Pokemon :: Pokemon()
{
    name = "";
    hp = 0;
    attack = 0;
    defense = 0;
    speed = 0;
    max = 0;
}

Pokemon :: Player(string aName, int aHp, int aAttack, int aDefense, int aSpeed, int aMax)
{
    name = aName;
    hp = aHp;
    attack = aAttack;
    defense = aDefense;
    speed = aSpeed;
    max = aMax;
}

void Pokemon :: readFile()
{
    /* split function which will split up file into the different stats assign stats to variables*/
}

string Pokemon :: getName()
{
    return name;
}

void Pokemon :: setName(string n)
{
    name = n;
}

int Pokemon :: get_hp()
{
    return hp;
}

void Pokemon :: set_hp(int hPoints)
{
    hp = hPoints;
}

int Pokemon :: getAttack()
{
    return attack;
}

void Pokemon :: setAttack(int a)
{
    attack = a;
}

int Pokemon :: getDefense()
{
    return defense;
}

void Pokemon :: setDefense(int d)
{
    defense = d;
}

int Pokemon :: getSpeed()
{
    return speed;
}

void Pokemon :: setSpeed(int s)
{
    speed = s;
}

int Pokemon :: getMax()
{
    return max;
}

void Pokemon :: setMax(int m)
{
    max = m;
}