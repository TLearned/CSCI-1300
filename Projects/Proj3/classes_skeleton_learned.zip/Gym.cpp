#include "gym.h"

Gym :: Gym()
{
    trainer = "";
    trainer_pokemon = "";
    tp_hp = 0;
    user = "";
    user_pokemon = "";
    up_hp = 0;
}

Gym :: Gym(string aTrainer, string aTrainer_pokemon, int a_tp_hp, string aUser, string aUser_pokemon,int a_up_hp)
{
    trainer = aTrainer;
    trainer_pokemon = aTrainer_pokemon;
    tp_hp = a_tp_hp;
    user = auser;
    user_pokemon = aUser_pokemon;
    up_hp = a_up_hp;
}

string Gym :: getTrainerName()
{
    return trainer;
}

void Gym :: setTrainerName(string tN)
{
    /* random function to decide name*/
}

string Gym :: getTrainer_pokemon()
{
    return trainer_pokemon;
}

void Gym :: setTrainer_pokemon(string tP)
{
    /* random function to decide active pokemon*/
}

int Gym :: get_tp_hp()
{
    return tp_hp;
}

void Gym :: set_tp_hp(int tHP)
{
    /* random function to decide hp ok pokemon*/
}

string Gym :: getUsername()
{
    return username;
}

void Gym :: setUsername(string u)
{
    username = u;
}

string Gym :: getUser_pokemon()
{
    return user_pokemon;
}

void Gym :: setUser_pokemon(string uP)
{
    user_pokemon = uP;
}

int Gym :: get_up_hp()
{
    return up_hp;
}

void Gym :: set_up_hp(int uHP)
{
    up_hp = uHP;
}