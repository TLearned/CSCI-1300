#ifndef CUSTOMER_H
#define CUSTOMER_H
#include <string>
using namespace std;

class Customer
{
  private:
    string customerName;
    int age;
    string region;
    string emailAddress;
    double money;
  public:

};

#endif
