// CS1300 Fall 2019
// Author: Tyler Learned
// Recitation: 1300-301 - Punith
// Homework 6 - Problem 1

#include <iostream>
#include <fstream>
#include <math.h>
using namespace std;

class Planet
{
    private;
        string planetName;
        double planetRadius;
        
    public;
        Planet()                                    //Default Constructor, initialize string to empty and radius to 0.0
        {
            planetName = "";
            planetRadius = 0.0
        }
        
        param constructor
        
        string getName(string planetName)
        {
           return planetName; 
        }
        
        void setName(string)
        {
            
        }
        
        double getradius(double planetRadius)
        {
            return planetRadius;
        }
        
        void setRadius(double)
        {
            
        }
        
        double getVolume(double planetRadius)
        {
            pow(double, double);
            double volume = (4 / 3) * pi * pow (planetRadius, 3);
            return volume;
        }
}

int main()
{
    
}