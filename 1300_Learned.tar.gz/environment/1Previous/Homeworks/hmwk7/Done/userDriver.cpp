// CS1300 Fall 2019
// Author: Tyler Learned
// Recitation: 1300-301 - Punith
// Homework 7 - Problem 1

int main()
{
    //Test Case 1
    User u1 = User();
    cout << u1.getUsername() << endl;
    
    //Test Case 2
    User u1 = User();
    cout << u1.getNumRatings() << endl;
}