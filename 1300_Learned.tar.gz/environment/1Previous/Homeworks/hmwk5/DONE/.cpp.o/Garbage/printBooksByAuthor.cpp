// CS1300 Fall 2019
// Author: Tyler Learned
// Recitation: 1300-301 - Punith
// Homework 5 - Problem 4

#include <iostream>
#include <fstream>
using namespace std;

int count = 0;
void printBooksByAuthor(string titles[], string authors[], int numOfBooks, string authorName)
{
    if(numOfBooks <= 0)
    {
        cout << "No books are stored" << endl;
    }
    for(int x = 0; x < numOfBooks; x++)
    {
        if(authorName == authors[x])
        {
            count = count++;
        }
        if(count <= 1)
        {
            cout << "There are no books by " << authorName << endl;
            return;
        }
        else
        {
            cout << "Here is a list of books by " << authorName << endl;
            break;
        }
    }
}

int main()
{
    
}