// CS1300 Fall 2019
// Author: Tyler Learned
// Recitation: 1300-301 - Punith
// Homework 4 - Extra Problem

#include <iostream>
#include <math.h>
using namespace std;

