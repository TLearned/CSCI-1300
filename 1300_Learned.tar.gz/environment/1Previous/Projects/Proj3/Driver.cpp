/*includes

level up code for in battles

pokedex code for centers

treasure code
1 of every 4 moves
1 of 2 is pokemon other is level up for a pokemon

die
1 of every 5 moves a pokemon will die

wild pokemon programming(30% chance)
within 2 tiles either way (5X5)
not location of center, gym, water, player, or other wild pokemon location
choice menu
fight- starts fight with fastest pokemon
switch active- user swithces pokemon
run- ((a *32)/b) +30 * c
go until outcome

user turns call user class menu function
move- n , s, e ,w
rest- location same, + 1 hp, - 1 pokeball
try luck - location same , maybe free pokemon
quit
go until quit

pokemon center 
all pokemon full hp
can switch party
exit command

gym
fight or switch
fight until all of one person's pokemon are fainted
win - users active pokemon level up, get all pokemon from trainer, badge, 5 balls, 60 pts, gym disappears from usability
loss - trainers active pokemon level up, teleport to go to pokecenter to heal

print map from pokemonmap.txt

cout enter name
user enters their name

welcome cout
user chooses starter pokemon

go until user quits(lose), earns 6 badges(win), or gets 8 different pokemon(win)

when it ends store win or loss, name and points into resultspokemon.txt