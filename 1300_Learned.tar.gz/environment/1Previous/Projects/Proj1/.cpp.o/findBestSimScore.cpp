// CS1300 Fall 2019
// Author: Tyler Learned
// Recitation: 1300-301 - No Favorite TA
// Project 1 - Problem 5

#include <iostream>
#include <math.h>
#include <string>
using namespace std;

double findBestSimScore(string genome, string sequence)
{
    int genomeLength = genome.length();
    int sequenceLength = sequence.length();
    double simParts = 0; //match
    double simScore = 0; //bestmatch
    if(genomeLength == 0 || sequenceLength == 0)
    {
        return 0;
    }
    if(sequenceLength > genomeLength)
    {
        return -1;
    }
        // for (int i = 0; i < genomeLength - sequenceLength; i++)
        // {
        //     for (int counter = 0; counter < genomeLength; counter++)
        //     {
        //         string substr = genome.substr(counter, sequenceLength);
        //         if (substr == sequence)
        //         {
        //             simParts = simParts++;
        //         }
        //         simScore = simParts/(substr.length());
                
        //     }
        // }
    //simScore = 1 / simParts;
    for (int i = 0; i <= genomeLength-sequenceLength; i++)
    {
        int matches = 0;
        string substr = genome.substr(i, sequenceLength);
        for (int i = 0; i <= substr.length(); i++)
        {
            if(substr[i] == sequence[i]) matches++;
        }
        simParts = (double)matches/(substr.length());
    }
    return simParts;
}

int main()
{
    //Test Case 1
    cout << findBestSimScore("ACTACT", "ACT") << endl;
    
    //Test Case 2
    cout << findBestSimScore("AACTAC", "ACT") << endl;
}