#include <iostream>
#include <string>
using namespace std;


int main()
{
  int rows = 3;
  int cols = 3;
  char array[3][3] = {
                       {'K', 'A', 'R'},
                       {'P', 'K', 'C'},
                       {'Z', 'A', 'R'}
                     };

int startI = 0;
int startJ = 0;
for(int i = startI; i <= startI + 1; i++)
{
    for(int j = startJ; j <= startI + 1; j++)
    {

    }
}

  return 0;
}
